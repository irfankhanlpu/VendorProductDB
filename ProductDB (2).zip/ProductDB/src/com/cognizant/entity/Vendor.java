package com.cognizant.entity;

public class Vendor {
	
	public Vendor(){}
	
	private int vendorId;
	
	private int quantity;

	public int getVendorId() {
		return vendorId;
	}

	public void setVendorId(int vendorId) {
		this.vendorId = vendorId;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	
	

}
